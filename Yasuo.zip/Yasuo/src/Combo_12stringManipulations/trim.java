package Combo_12stringManipulations;

public class trim {
    public static void main(String[] args) {

        String str="    Oha abi cok iyi yaaa.   ";

        System.out.println(str.trim()); //bastaki ve sonraki sacma bosluklari siler
    }
}
