package Combo_14methodCreation;

public class tarihSehirAlma2 {
    public static void main(String[] args) {

        System.out.println(tarihSehirAlma.sehirAl());
    }
}
