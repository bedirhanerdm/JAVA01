package Combo_04Casting;

public class Odev2 {
    public static void main(String[] args) {
        int i=45;
        short s= (short) i;
        System.out.println("s = " + s);
        
        byte b=(byte)s;
        System.out.println("b = " + b);

    }
}
