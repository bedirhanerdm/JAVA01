package Combo_04Casting;

public class Odev3 {
    public static void main(String[] args) {
        float x=456.5f;
        System.out.println("x = " + x);
    }
}
