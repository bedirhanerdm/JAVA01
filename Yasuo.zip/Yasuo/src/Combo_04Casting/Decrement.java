package Combo_04Casting;

public class Decrement {
    public static void main(String[] args) {

        int x=5;

        x-=3;


        System.out.println(x);
    }
}
