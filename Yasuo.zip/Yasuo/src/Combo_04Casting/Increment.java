package Combo_04Casting;

public class Increment {
    public static void main(String[] args) {

        int x=5;

        x += 6; //x = x + 6 ile aynidir
        x++;    //x = x + 1 ile aynidir
        x*=3;   //x = x * 3 ile aynidir

        System.out.println(x);
    }
}
