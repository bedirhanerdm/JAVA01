package Combo_04Casting;

public class Odev4 {
    public static void main(String[] args) {
        double d=255.36;
        int i=(int)d;
        byte b=(byte)i;

        System.out.println(b);
    }
}
