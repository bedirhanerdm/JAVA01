package Combo_04Casting;

public class Odev5 {
    public static void main(String[] args) {
        int x=59;
        int y=13;

        System.out.println("x/y= "+x/y);
        System.out.println("y/x= "+y/x);
    }
}
