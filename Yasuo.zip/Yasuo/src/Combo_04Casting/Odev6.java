package Combo_04Casting;

public class Odev6 {
    public static void main(String[] args) {
        int x=28;
        double y=2.5;

        System.out.println("x/y= "+x/y);
    }
}
