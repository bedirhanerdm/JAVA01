package Combo_04Casting;

public class Odev1 {
    public static void main(String[] args) {
        byte b= 56;
        short s=(short)b;
        System.out.println("s = " + s);
        
        int i=(int)s;
        System.out.println("i = " + i);
        
        float f=(float)i;
        System.out.println("f = " + f);
        
        double d=(double)f;
        System.out.println("d = " + d);
        
        
        
        




    }
}
