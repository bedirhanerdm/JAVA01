package Combo_01Variables;

public class Yasuo_Malphite {
    public static void main(String[] args) {
        System.out.println("zıplatan bişeler al");
    }
}
