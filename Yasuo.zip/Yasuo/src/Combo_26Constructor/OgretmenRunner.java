package Combo_26Constructor;

public class OgretmenRunner {

    public static void main(String[] args) {


        Ogretmen ogretmen1 = new Ogretmen();
        System.out.println("Ogretmen1: " + ogretmen1);

        System.out.println("");

        Ogretmen ogretmen2 = new Ogretmen("Ahmet Bedirhan", "Erdem","25/10/2001","QA Tester","Aviation");
        System.out.println("Ogretmen2: " + ogretmen2);




    }
}
