package Combo_26Constructor;

public class KamyonRunner {

    public static void main(String[] args) {

        Kamyon kamyon1 = new Kamyon();

        System.out.println("Kamyon1 ozellikleri: " + kamyon1.toString());

        System.out.println("");




        Kamyon kamyon2 = new Kamyon("Mercedes", "4140", 2015, 250000);

        System.out.println("Kamyon2 bilgileri: " + kamyon2);






    }
}
