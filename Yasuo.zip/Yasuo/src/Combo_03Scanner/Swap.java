package Combo_03Scanner;

public class Swap {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        int c=0;
        c=a;
        a=b;
        b=c;
        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}
