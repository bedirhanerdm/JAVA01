package Combo_03Scanner;

public class Oylesine {
    public static void main(String[] args) {
        String a="abi";
        String b="para";
        int x=50;
        String e="kurbanın";
        String c="yolla,";
        String f="benim<3";
        String d="kesene bereket muck";
        char y='$';
        System.out.println("Cok onemli bise dicem");
        System.out.println("Asagiyi okuyun");
        System.out.println(a+" "+b+" "+c+" "+d);
        System.out.println("saka saka");
        System.out.println(e+" "+x+y+"i "+f);

    }
}
