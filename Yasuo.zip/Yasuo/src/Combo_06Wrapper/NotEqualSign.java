package Combo_06Wrapper;

public class NotEqualSign {
    public static void main(String[] args) {

        boolean sonuc= 5+2!=7;
        boolean sonuc2=5*2!=15;

        System.out.println("sonuc = " + sonuc);
        System.out.println("sonuc2 = " + sonuc2);

        System.out.println(!(3*5>7));
    }
}
