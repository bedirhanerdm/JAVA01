package Combo_06Wrapper;

public class DoubleEqualSign {
    public static void main(String[] args) {

        boolean sonuc= 5+2==7;
        boolean sonuc2= 5*2==15;

        System.out.println("sonuc = " + sonuc);
        System.out.println("sonuc2 = " + sonuc2);
    }
}
