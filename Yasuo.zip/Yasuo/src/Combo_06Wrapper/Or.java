package Combo_06Wrapper;

public class Or {
    public static void main(String[] args) {

        int a=15;
        int b=354;

        System.out.println(a>b || a>=15);

        // '||' isareti veya anlamina gelir, biri dogruysa sonuc dogru olur
    }
}
