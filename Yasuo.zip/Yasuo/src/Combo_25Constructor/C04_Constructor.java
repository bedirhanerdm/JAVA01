package Combo_25Constructor;

public class C04_Constructor {

    public static void main(String[] args) {

        C03 obj1 = new C03();

        // bir classta 2. bir constructor olusturursak java defaultu siler

        obj1.method01();

    }
}
