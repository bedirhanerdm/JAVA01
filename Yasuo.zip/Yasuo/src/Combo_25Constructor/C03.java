package Combo_25Constructor;

public class C03 {

    String isim = "Etka";

    public void method01(){
        System.out.println("C03 method calisti");

    }






}
