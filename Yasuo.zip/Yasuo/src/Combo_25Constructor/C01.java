package Combo_25Constructor;

public class C01 {


    int sayi;

    public void deneme(){

        System.out.println("C01den olusturulan bu method, bu classta da calisir");
    }

}
