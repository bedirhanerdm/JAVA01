package Combo_02Variables;

public class Yasuo_Malphite_Orianna2 {
    public static void main(String[] args) {
        int sayi=10;
        boolean guzelMi=true;
        char sayim='3';

        System.out.println(sayi);
        System.out.println("sayi");
        System.out.println("sayi: " + sayi);
    }
}
