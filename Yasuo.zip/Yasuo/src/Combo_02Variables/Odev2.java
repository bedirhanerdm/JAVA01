package Combo_02Variables;

public class Odev2 {
    public static void main(String[] args) {
        String Isminiz="Bedirhan";
        String SoyIsminiz="Erdem";
        System.out.println("Isminiz = " + Isminiz);
        System.out.println("SoyIsminiz = " + SoyIsminiz);
    }

}
