package Combo_02Variables;

public class Odev1 {
    public static void main(String[] args) {
        int x=25;
        boolean EveGittinMi=true;
        double y=x/3;

        System.out.println(x);
        System.out.println(EveGittinMi);
        System.out.println(y);
    }
}
