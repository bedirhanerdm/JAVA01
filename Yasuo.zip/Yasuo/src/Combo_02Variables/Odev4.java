package Combo_02Variables;

public class Odev4 {
    public static void main(String[] args) {
        int x=67;
        double y=45/3;
        System.out.println(x + y);
    }
}
