package Combo_02Variables;

public class Yasuo_Malphite_Orianna {
    public static void main(String[] args) {
        int vize=70;
        int finaI=31;
        int ort= (vize+ finaI)/2;
        System.out.println(ort);
    }
}
