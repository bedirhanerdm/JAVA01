package Combo_02Variables;

public class Odev5 {
    public static void main(String[] args) {
        char x='#';
        System.out.println(x);
    }
}
