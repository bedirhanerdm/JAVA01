package Combo_02Variables;

public class Odev6 {
    public static void main(String[] args) {
        int x=56;
        char y=4;
        System.out.println(x + y);
    }
}
