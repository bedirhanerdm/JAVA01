package Combo_02Variables;

public class Odev3 {
    public static void main(String[] args) {
        int x=17;
        int y=58;
        System.out.println(x + y);
    }
}
