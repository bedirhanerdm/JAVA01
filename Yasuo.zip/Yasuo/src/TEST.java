import java.util.Scanner;

public class TEST {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen dakika turunden bir zaman giriniz");
        double dk = scan.nextInt();

        double gun1 = dk/1440;
        double yil1 = gun1/365;

        int gun2 = (int) gun1;
        int yil2 = (int) yil1;

        int temp = 0;
        temp = gun2;

        temp = gun2%365;
        yil2 = gun2/365;

        System.out.println(dk + " dakika yaklasik olarak: " + yil2 + " yil, " + temp + " gundur.");




    }
}
