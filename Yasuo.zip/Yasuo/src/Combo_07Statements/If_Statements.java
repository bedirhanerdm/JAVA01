package Combo_07Statements;

import javax.swing.*;

public class If_Statements {
    public static void main(String[] args) {

        int sayi=12;

        if(sayi>0){
            System.out.println("sayi pozitif");
        }
        if (sayi%2==0){
            System.out.println("sayi cift");
        }
        if (sayi%5==0){
            System.out.println("sayi 5'in tam kati");
        }
    }
}
