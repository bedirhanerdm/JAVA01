package AA_Practice;

import java.util.Scanner;

public class A01 {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Isim soyisim giriniz");
        String isim=scan.nextLine();
        isim=isim.toUpperCase();

        System.out.println("Memleketinizi giriniz");
        String memleket=scan.next();
        memleket=memleket.toUpperCase();

        System.out.println("Konumunuzu giriniz");
        String konum=scan.next();
        konum=konum.toUpperCase();

        System.out.println("Yasinizi giriniz");
        double yas= scan.nextDouble();

        System.out.println("boyunuzu cm degeri olarak giriniz");
        double boy= scan.nextDouble();
        boy=boy/100;

        System.out.println("Yasadiginiz konumu seviyor musunuz? true/false");
        String seviyorMu=scan.next().toLowerCase();

        if (seviyorMu.equals("true")) {
            System.out.println("Isminiz/Soyisminiz= " + isim + "\nMemleketiniz= " + memleket
            + "\nKonumunuz= " + konum + "\nYasiniz= " + yas + "\nBoyunuz= " + boy + " metre");

        } else if (seviyorMu.equals("false")) {
            System.out.println("Tasinmayi deneyebilirsiniz");

        }else {
            System.out.println("Lutfen gecerli deger giriniz");

        }


    }
}
