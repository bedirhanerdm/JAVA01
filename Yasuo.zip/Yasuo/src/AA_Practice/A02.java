package AA_Practice;

import java.util.Scanner;

public class A02 {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen Y/N ikilisinden birini giriniz");
        char ch=scan.next().charAt(0);

        if (ch=='Y' || ch=='y'){
            System.out.println("YES");
        } else if (ch=='n' || ch=='N') {
            System.out.println("NO");
        }else{
            System.out.println("Lutfen gecerli deger giriniz");
        }
    }
}
