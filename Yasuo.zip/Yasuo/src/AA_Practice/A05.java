package AA_Practice;

import java.util.Scanner;

public class A05 {
    public static void main(String[] args) {

        /*
		name1 ve name2 degiskenlerini olusturun.
		name1 degiskeninin karakter sayisi cift ise kelimenin ortasina name2 yi yerlestirin.
		name1 degiskeninin karakter sayisi tek ise "name1 cift sayili olmadigi icin ortasina yerlestiremedik" yazdirin.
		          e.g:
		         name1= mehmet
		         name2= ahmet
		         Print ==> mehahmetmet
		*/

        Scanner scan=new Scanner(System.in);
        System.out.println("Lutfen bir isim giriniz");
        String isim1=scan.next();

        System.out.println("Lutfen 2. bir isim giriniz");
        String isim2=scan.next();

        System.out.println(isimIslemi(isim1,isim2));
    }

    private static String isimIslemi(String isim1, String isim2) {

        if ((isim1.length()%2)==0){

        return (isim1.substring(0, isim1.length()/2))+isim2
                    +(isim1.substring(isim1.length()/2));


        } else {

            return "Ilk ismin karakter sayisi cift olmadigi icin islem yapilamadi";
        }



    }
}
