package AA_Practice;

import java.util.Scanner;

public class A04 {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Ilk kelimeyi girin");
        String s1=scan.next().toLowerCase();

        System.out.println("2. Kelimeyi girin");
        String s2=scan.next().toLowerCase();

        System.out.println("3. kelimeyi girin");
        String s3=scan.next().toLowerCase();

        System.out.println("4. kelimeyi girin");
        String s4=scan.next().toLowerCase();

        System.out.println((s1.substring(0,1).toUpperCase())+s1.substring(1)
        + " " + s2+ " " + s3 + " " + s4 + ".");
    }
}
