package AA_Practice;

import java.util.Scanner;

public class A03 {
    public static void main(String[] args) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Notunuzu giriniz");
        double not=scan.nextDouble();

        if (not<0 || not>100){
            System.out.println("Lutfen gecerli bir not giriniz");

        } else if (not>=90 && not<=100) {
            System.out.println("A aldiniz");

        } else if (not>=80 && not<90) {
            System.out.println("B aldiniz");

        } else if (not>=70 && not<80) {
            System.out.println("C aldiniz");

        } else if (not>=60 && not<70) {
            System.out.println("D aldiniz");

        }else {
            System.out.println("F ile kaldiniz");
        }

    }
}
