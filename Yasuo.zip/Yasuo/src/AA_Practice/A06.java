package AA_Practice;

import java.util.Scanner;

public class A06 {
    public static void main(String[] args) {

        /*
		Kullanicidan bir kelime girmesini isteyin.
		* Sozcukte tek sayida karakter ve 3 veya daha fazla karakter iceriyorsa,
		* kelimenin ortasindaki karakteri yazdirin.
		*/

        String w="";

        System.out.println(karakterSayisi(w));

    }

    private static String karakterSayisi(String w) {

        Scanner scan=new Scanner(System.in);
        System.out.println("Bir kelime giriniz");
        w=scan.next();

        if (w.length()%2!=0 && w.length()>=3) {

            return w.substring(w.length()/2,(w.length()/2)+1);

        }else {

            return "Kelime 3 karakterden az veya karakter sayisi 2ye tam bolunuyor";
        }


    }
}
