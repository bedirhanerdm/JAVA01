package Combo_22MultiDimensionalArrays;

import java.util.Arrays;

public class C10_Sort {

    public static void main(String[] args) {

        // Sort kucukten buyuge siralatir


        Integer[] sayilar = {3,6,4,1,2,7,5};

        Arrays.sort(sayilar);

        System.out.println(Arrays.toString(sayilar));

    }
}
