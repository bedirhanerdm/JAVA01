package Combo_16ForLoop;

public class C02_ForLoop_Hatalar {
    public static void main(String[] args) {

        //baslangictan bitis noktasina yaklasmiyorsak sonsuz loop olusur.

       // for (int i=0; i>-10; i++){
       //     System.out.println(i + " ");
       // }
                            //CALISTIRMA!!!! pc sagligi icin



        for (int i=0; i >5; i+=2){      //for loop calisir ama loop body hic devreye girmez (calismaz).
            System.out.println(i+" ");

        }
    }
}

//CALISTIRMA!!!! pc sagligi icin
