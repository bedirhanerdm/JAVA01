package Combo_16ForLoop;

public class C03_ForLoopExamples {
    public static void main(String[] args) {

        /*
        10 ile 30 arasindaki(10 ve 30 dahil) sayilari aralarinda virgul olarak ayni satirda yazdirin
         */

        for (int i=10; i<=30; i++){
            System.out.print(i+", ");
        }
    }
}
