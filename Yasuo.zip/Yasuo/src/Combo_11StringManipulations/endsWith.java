package Combo_11StringManipulations;

public class endsWith {
    public static void main(String[] args) {

        String str="Ah be Java";

        System.out.println(str.endsWith("ava")); //true

        System.out.println(str.endsWith("be Java")); //true

        System.out.println("Ah be Java"); //true

        System.out.println(str.endsWith("")); //hiclige ragmen true


    }
}
